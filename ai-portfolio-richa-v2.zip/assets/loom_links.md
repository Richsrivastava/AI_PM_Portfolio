# Loom Placeholders
- Project 1 demo: https://www.loom.com/share/your-p1-demo-id (replace me)
- Project 2 demo: https://www.loom.com/share/your-p2-demo-id (replace me)
- Dashboard walkthrough: https://www.loom.com/share/your-dashboard-demo-id (replace me)
