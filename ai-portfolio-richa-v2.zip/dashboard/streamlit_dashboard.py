import streamlit as st
import pandas as pd
import sqlite3
import matplotlib.pyplot as plt
from pathlib import Path

st.title("AI PM Portfolio Dashboard")

db_paths = list(Path(".").glob("**/telemetry.db"))
eval_paths = list(Path(".").glob("**/eval_results.csv"))

st.subheader("Telemetry (latency, tokens, cost)")
if db_paths:
    db = st.selectbox("Select a telemetry DB", db_paths)
    con = sqlite3.connect(db)
    df = pd.read_sql_query("SELECT * FROM telemetry ORDER BY ts DESC LIMIT 2000", con)
    st.dataframe(df.head(50))
    if "latency_ms" in df.columns:
        fig = plt.figure()
        df["latency_ms"].plot(kind="hist", bins=30)
        plt.xlabel("Latency (ms)"); plt.ylabel("Count")
        st.pyplot(fig)
else:
    st.info("No telemetry.db found yet. Run an app to generate logs.")

st.subheader("Eval Results")
if eval_paths:
    p = st.selectbox("Select eval results", eval_paths)
    df = pd.read_csv(p)
    st.dataframe(df.head(50))
else:
    st.info("No eval_results.csv found yet. Run run_evals.py in a project.")
