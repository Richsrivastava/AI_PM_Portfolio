import os
from typing import Optional

# Optional SDK imports
try:
    import anthropic
except Exception:
    anthropic = None

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

def _mock_completion(prompt: str) -> str:
    return "[MOCK OUTPUT]\nThis is a concise, useful answer. (No API keys detected or call failed.)"

def _anthropic_complete(prompt: str, system: Optional[str]=None, max_tokens: int=400) -> str:
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key or anthropic is None:
        raise RuntimeError("Anthropic SDK or API key not available")
    model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-latest")
    client = anthropic.Anthropic(api_key=api_key)
    msg = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        temperature=float(os.getenv("LLM_TEMPERATURE", "0.2")),
        system=system or "You are a concise, helpful assistant.",
        messages=[{"role": "user", "content": prompt}],
    )
    # Messages API returns content as a list of blocks
    parts = getattr(msg, "content", [])
    text = ""
    for p in parts:
        if hasattr(p, "text"):
            text += p.text
        elif isinstance(p, dict):
            text += p.get("text", "")
        else:
            text += str(p)
    return text.strip() or _mock_completion(prompt)

def _openai_complete(prompt: str, system: Optional[str]=None, max_tokens: int=400) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or OpenAI is None:
        raise RuntimeError("OpenAI SDK or API key not available")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    client = OpenAI(api_key=api_key)
    msg = client.chat.completions.create(
        model=model,
        temperature=float(os.getenv("LLM_TEMPERATURE", "0.2")),
        messages=[
            {"role":"system","content": system or "You are a concise, helpful assistant."},
            {"role":"user","content": prompt},
        ],
        max_tokens=max_tokens
    )
    return (msg.choices[0].message.content or "").strip() or _mock_completion(prompt)

def llm_complete(prompt: str, system: Optional[str]=None, max_tokens: int=400) -> str:
    """
    Prefer Anthropic if key present, else OpenAI, else mock.
    Any error falls back to mock to avoid UX breaks.
    """
    try:
        if os.getenv("ANTHROPIC_API_KEY"):
            return _anthropic_complete(prompt, system, max_tokens)
        if os.getenv("OPENAI_API_KEY"):
            return _openai_complete(prompt, system, max_tokens)
    except Exception:
        pass
    return _mock_completion(prompt)
