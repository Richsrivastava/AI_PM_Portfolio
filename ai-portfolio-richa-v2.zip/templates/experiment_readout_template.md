# Experiment Readout: <Name>
**Date range:** <start–end>  
**Owner:** Richa Srivastava

## Hypothesis
## Variants
## Metrics
## Results
- Table of KPIs by variant
- Statistical notes / caveats

## Decision
## Next Steps
