# Metrics Schema
- task_success (0/1 per task; rubric in eval set)
- time_to_value_sec
- tokens_user, tokens_total
- latency_ms (p50, p95)
- cost_usd (approx)
- safe_fallback_rate
- hallucination_rate
- calibration_proxy
