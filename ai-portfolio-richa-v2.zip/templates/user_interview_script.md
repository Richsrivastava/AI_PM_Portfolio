# User Interview Script (15–20 min)
1. What task brought you here today?
2. How clear were the starting options?
3. Did you achieve your task? What was hard?
4. When did you doubt the answer?
5. Did it feel fast enough? Worth it?
6. What would have made this 2x better?
