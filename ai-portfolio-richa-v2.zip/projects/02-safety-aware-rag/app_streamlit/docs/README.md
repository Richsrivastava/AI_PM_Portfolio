Place public .txt docs here.
