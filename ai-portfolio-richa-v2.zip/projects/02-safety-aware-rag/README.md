# Project 2: Safety-aware RAG
**Owner:** Richa Srivastava

Goal: Confidence-gated answers with citations, refusals, and safe fallbacks.
