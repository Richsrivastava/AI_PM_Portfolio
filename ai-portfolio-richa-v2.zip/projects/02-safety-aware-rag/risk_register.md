# Risk Register
| Risk | Likelihood | Impact | Mitigation | Owner | Status |
|------|------------|--------|------------|-------|--------|
| Hallucination | M | H | Confidence gating + citations | Owner | Open |
| PII leakage | M | H | Redaction, allowlists | Owner | Open |
| Harmful content | L | H | Content filters, refusal messages | Owner | Open |
