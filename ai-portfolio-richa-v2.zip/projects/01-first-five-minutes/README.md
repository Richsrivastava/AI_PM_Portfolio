# Project 1: First 5 Minutes to Value
**Owner:** Richa Srivastava

Goal: Reduce time-to-first-success for a general assistant via onboarding patterns.

Variants:
- A: Blank chat
- B: Wizard checklist
- C: Example gallery + prompt chips
