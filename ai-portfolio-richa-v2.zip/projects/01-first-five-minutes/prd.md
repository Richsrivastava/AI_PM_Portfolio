# PRD: First 5 Minutes to Value
**Owner:** Richa Srivastava  
**Date:** 2025-08-17  
**Status:** Draft

## 1) Problem & Goals
New users struggle to discover what an AI assistant can do. We will reduce time-to-first-success and boost early retention via opinionated onboarding patterns.
- **Goal 1:** Help a new user accomplish a task in < 120s (p50) without prior instruction.
- **Goal 2:** Increase first-session task success rate to ≥ 65%.
- **Goal 3:** Improve 48h return rate by +8pp vs. baseline.

## 2) Success Metrics (Anthropic-aligned)
**Activation & Retention Proxies**
- **Time-to-first-success (TTV):** p50 < 120s, p95 < 300s
- **First-session task_success:** ≥ 65% (rubric-graded on eval set + sampled user sessions)
- **D1/D2/D7 return proxy:** 48h return ≥ 35% (target +8pp)

**Quality & Reliability**
- **Task success (offline):** ≥ 0.75 keyphrase/rubric score on evals for top use-cases
- **Refusal appropriateness:** ≥ 95% (manual spot-checks on sampled refusals)
- **Hallucination rate:** ≤ 3% on eval set (citation/verification when applicable)

**Safety & Steerability**
- **Guardrail trigger rate:** track; aim for high precision on harmful patterns
- **Confidence-aware UX:** ≥ 90% of low-confidence answers use clarify/fallback

**Cost & Latency**
- **p95 latency budget:** ≤ 2.5s for generation step
- **Cost/user (tokens):** track; hold flat or improve vs. baseline with caching

## 3) Users & Scope
- New users (consumer/prosumer) arriving via homepage or invite.
- In scope: onboarding UI variants (Blank Chat, Wizard, Gallery), example library, prompt chips.
- Out of scope: account, billing, workspace sharing.

## 4) Requirements
- Instrumentation: event logs (TTV, tokens, latency), session sampling for qual.
- A/B/C experiments with rollout guardrails.
- Accessibility (keyboard nav, readable defaults).

## 5) Experiments
- **A/B/C:** Blank chat vs. Wizard vs. Gallery; primary KPI = task_success; secondary = TTV, tokens/user.
- **Prompt scaffolds:** chips vs. inline hints.
- **Results cadence:** weekly readout with decision.

## 6) Risks & Mitigations
- Wizard fatigue → keep under 3 clicks; escape hatch to chat.
- Overfitting to eval set → rotate holdout set monthly.
- Cost creep → prompt compression, caching, example re-use.
