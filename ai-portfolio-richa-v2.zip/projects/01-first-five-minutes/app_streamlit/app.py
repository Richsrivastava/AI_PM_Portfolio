import os, time, uuid
import streamlit as st
from telemetry import log
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../common")))
from model_clients import llm_complete


st.set_page_config(page_title="First 5 Minutes", layout="wide")
st.title("First 5 Minutes to Value")

sid = st.session_state.get("sid") or str(uuid.uuid4())
st.session_state["sid"] = sid

variant = st.selectbox("Onboarding variant", ["A - Blank Chat","B - Wizard","C - Gallery"])

st.markdown("### Try a task")
task = st.selectbox("Task", ["Summarize a document","Draft an email","Plan a trip","Analyze a CSV"])
details = st.text_area("Details", "Paste text or describe your task...")

def mock_llm(prompt: str) -> str:
    return "[MOCK OUTPUT]\nThis is a concise, useful answer."

if st.button("Run"):
    t0 = time.time()
    out = mock_llm(details)
    dt = int((time.time()-t0)*1000)
    st.code(out)
    log(sid, variant.split(" ")[0], task, dt, len(details.split()), len(out.split()))
