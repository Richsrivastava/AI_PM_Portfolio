# Experiment Readout: Onboarding Variants
**Owner:** Richa Srivastava

- Hypothesis: Guided onboarding increases task success and reduces TTV.
- Variants: A/B/C
- Metrics: task_success, time_to_value_sec, tokens_user, latency_ms
