def test_truthy():
    assert True
