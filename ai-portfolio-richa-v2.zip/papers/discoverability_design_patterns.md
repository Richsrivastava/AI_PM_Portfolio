---
title: Design Patterns for Discoverability in AI Assistants
author: Richa Srivastava
date: 2025-08-17
---

Outline:
- Onboarding variants (blank, wizard, gallery)
- KPIs: time-to-value, retention proxies, tokens/user
- Results from Project 1 A/B/C
