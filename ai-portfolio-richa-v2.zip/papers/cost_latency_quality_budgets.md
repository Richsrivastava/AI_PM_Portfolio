---
title: Cost × Latency × Quality Budgets in Consumer LLMs
author: Richa Srivastava
date: 2025-08-17
---

Outline:
- Define budgets and tradeoffs
- Observability: tokens, p95 latency, cost/user
- Guardrails and graceful degradation
