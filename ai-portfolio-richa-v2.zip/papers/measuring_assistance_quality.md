---
title: Measuring AI Assistance Quality: From Task Success to Confidence-Calibrated UX
author: Richa Srivastava
date: 2025-08-17
---

Outline:
- Task success, error taxonomy, calibration proxy
- Confidence-aware UX (citations, refusal, clarify)
- Charts from dashboard and Project 2
